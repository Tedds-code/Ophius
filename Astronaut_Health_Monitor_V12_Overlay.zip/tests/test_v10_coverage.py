# Made in cooperation with ChatGPT
import unittest
from pathlib import Path
from astro_health.astronaut_assessment import assess_measurement, assess_condition, load_rules


class ExpandedRulesTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.rules = load_rules(Path('config/thresholds.json'))

    def test_skin_temperature_uses_json_thresholds_without_inventing_body_temp(self):
        self.assertEqual(assess_measurement('skin_temperature', 36.8, 'degC', self.rules).status, 'good')
        self.assertEqual(assess_measurement('skin_temperature', 37.9, 'degC', self.rules).status, 'caution')
        self.assertEqual(assess_measurement('skin_temperature', 39, 'degC', self.rules).status, 'critical')
        self.assertEqual(assess_measurement('skin_temperature', 32, 'degC', self.rules).status, 'critical')

    def test_blood_pressure_aliases_and_qtc(self):
        self.assertEqual(assess_measurement('systolic_pressure', 124, 'mmHg', self.rules).status, 'caution')
        self.assertEqual(assess_measurement('diastolic_pressure', 130, 'mmHg', self.rules).status, 'critical')
        self.assertEqual(assess_measurement('qtc_interval_male', 510, 'ms', self.rules).status, 'critical')

    def test_co2_requires_average_and_pressure(self):
        kw={'window_values': {'1_hour_average': 4000}, 'cabin_pressure_mmhg':760}
        self.assertEqual(assess_measurement('co2_concentration',4000,'ppm',self.rules).status,'unassessed')
        self.assertEqual(assess_measurement('co2_concentration',4000,'ppm',self.rules,**kw).status,'critical')
        kw['window_values']={'1_hour_average': 3000}
        self.assertEqual(assess_measurement('co2_concentration',3000,'ppm',self.rules,**kw).status,'good')

    def test_conditions_are_identified(self):
        self.assertEqual(assess_condition('nasal_congestion_duration_hours', 73, 'hours', self.rules).status, 'critical')
        self.assertEqual(assess_condition('nasal_congestion_duration_hours', 72, 'hours', self.rules).status, 'good')
        self.assertEqual(assess_condition('symptom_duration_hours', 100, 'hours', self.rules).status, 'unassessed')

    def test_radiation_gated(self):
        self.assertEqual(assess_measurement('cns_dose_30d', 600, 'mGy', self.rules).status, 'unassessed')
        self.assertEqual(assess_measurement('lens_dose', 900, 'mGy-Eq', self.rules).status, 'unassessed')

if __name__=='__main__': unittest.main()
